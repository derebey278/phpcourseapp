<?php
    $urunler = array("samsung s23","samsun s24");
?>