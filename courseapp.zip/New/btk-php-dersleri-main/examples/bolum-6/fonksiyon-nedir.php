<?php

    // Fonksiyon Nedir?

    // Built-in Fonksiyonlar

    echo date('Y/m/d');
    echo "<br>";
    echo strlen("Merhaba BTK");

    // 3rd libs (fonksiyon)
    // Kullanıcı Tanımlı Fonksiyonlar

?>