<ul>
    <?php foreach ($urunler as $urun) {
        echo "<li>$urun</li>";
    }?>
</ul>