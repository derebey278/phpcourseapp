<nav class="navbar navbar-expand-lg bg-primary navbar-dark">
    <div class="container">
        <a href="index.php" class="navbar-brand">CourseApp</a>
       
        <ul class="navbar-nav me-auto">
            <li class="nav-item">
                <a href="index.php" class="nav-link active">Anasayfa</a>
            </li>
            <?php
            session_start();
           if($_SESSION["user_type"]=="admin"):
            ?>
            <li class="nav-item">
                <a href="admin-categories.php" class="nav-link">Admin kategori</a>
            </li>
            <li class="nav-item">
                <a href="admin-courses.php" class="nav-link">Admin kurs</a>
            </li>
            <?php endif ?>
            </ul><ul class="navbar-nav me-auto">
            <?php  session_start();
if (isset($_SESSION["loginin"]) && $_SESSION["loginin"] == true):
 ?>
                <li class="nav-item">
                    <a href="logout.php" class="nav-link">cikis</a>
                </li>
                
         <?php else: ?>        
                <li class="nav-item">
                    <a href="login.php" class="nav-link">giris</a>
                </li>
                <li class="nav-item">
                    <a href="register.php" class="nav-link">kayit</a>
                </li>
            <?php endif; ?>   
        </ul>

        

        <form action="courses.php" class="d-flex" method="get">
            <input type="text" name="q" class="form-control me-2" placeholder="Keyword">
            <button type="submit" class="btn btn-warning">Ara</button>
        </form>
    </div>
</nav>