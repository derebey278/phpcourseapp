<nav>
    <a href="index.php">Anasayfa</a>
    <a href="contact.php">İletişim</a>
</nav>