<?php
require "libs/variables.php";
require "libs/functions.php";
?>

<?php include "partials/_header.php"; ?>
<?php include "partials/_navbar.php"; ?>

<?php
$usernameErr = $emailErr = $passwordErr = $repasswordErr = "";
$username = $email = $password = $repassword  = "";


 ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); 

if($_POST){
$data=  getUsers($_POST['username']);
  $veri = mysqli_fetch_all($data);
  $data2=  getMail($_POST['email']);
  $veri2 = mysqli_fetch_all($data2);
if(mysqli_num_rows($data)>0){
  $usernameErr = "username zaten kayitli";
}
if(mysqli_num_rows($data2)>0){
  $emailErr = "email zaten kayili";
}
else{
$username= $_POST['username'];
$email= $_POST['email'];
$password= $_POST['password'];
createUsers($username, $email, $password);
  }
  
  }
  

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
  
  
  
  
  
  
  
  if (empty($_POST["username"])) {
    $usernameErr = "username gerekli alan.";
  } else {
    $username = safe_html($_POST["username"]);
  }
  if (empty($_POST["email"])) {
    $emailErr = "email gerekli alan.";
  } else {
    $email = safe_html($_POST["email"]);
  }
  if (empty($_POST["password"])) {
    $passwordErr = "password gerekli alan.";
  } else {
    $password = safe_html($_POST["password"]);
  }
  if ($_POST["password"] != $_POST["repassword"]) {
    $repasswordErr = "parola tekrar alanı eşleşmiyor.";
  } else {
    $repassword = safe_html($_POST["repassword"]);
  }
}
?>

<div class="container my-3">

    <div class="row">
        <div class="col-12">
           <form action="register.php" method="post">
            <div class="mb-3">
                <label for="username">Kullanıcı Adı</label>
                <input type="text" name="username" class="form-control" required value="<?php echo $username; ?>">
                <div class="text-danger"><?php echo $usernameErr; ?></div>
            </div>
            <div class="mb-3">
                <label for="email">Eposta</label>
                <input type="email" name="email" class="form-control" required value="<?php echo $email; ?>">
                <div class="text-danger"><?php echo $emailErr; ?></div>
            </div>
            <div class="mb-3">
                <label for="password">Parola</label>
                <input type="password" name="password" required class="form-control" value="<?php echo $password; ?>">
                <div class="text-danger"><?php echo $passwordErr; ?></div>
            </div>
            <div class="mb-3">
                <label for="repassword">Parola Tekrar</label>
                <input type="password" name="repassword" required class="form-control">
                <div class="text-danger"><?php echo $repasswordErr; ?></div>
            </div>
   
            <button type="submit" class="btn btn-primary">Kayıt Ol</button>
           </form>
        </div>
    </div>

</div>
<?php include "partials/_footer.php"; ?>
