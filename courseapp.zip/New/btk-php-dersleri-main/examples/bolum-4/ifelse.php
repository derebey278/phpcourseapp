<?php

    // Koşullu Durumlar

        // 1- if-else
        // 2- Switch Bloğu
        // 3- Ternary Operatörü

    $username = "admin";
    $password = "1234";

    if ($username == "admin") {

        if ($password == "1234") {
            echo "Merhaba BTK";
        } else {
            echo "parola yanlış";
        }   

    } else {
        echo "username yanlış";
    }

    #soru1
    #soru2
    #soru3
    #else


?>