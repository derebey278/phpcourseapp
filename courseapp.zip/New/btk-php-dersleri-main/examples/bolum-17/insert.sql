INSERT INTO `products`(`title`, `price`, `description`) VALUES ('iphone 14', 20000, 'güzel telefon');
INSERT INTO `products`(`title`, `price`, `description`) VALUES ('iphone 15', 30000, 'güzel telefon');
INSERT INTO `products`(`title`, `price`, `description`) VALUES ('iphone 16', 40000, 'güzel telefon');
INSERT INTO `products`(`title`, `price`, `description`) VALUES ('iphone 17', 50000, 'güzel telefon');