<?php
    /*  
        +       Toplama                 $x + $y         
        -       Çıkarma                 $x - $y     
        *       Çarpma                  $x * $y         
        /       Bölme                   $x / $y         
        %       Mod Alma                $x % $y         
        **      Üs Alma                 $x ** $y
        ++$x    İşlem öncesi arttırma   
        --$x    İşlem öncesi azaltma    
        $x++    İşlem sonrası arttırma  
        $x--    İşlem sonrası azaltma   
    */

    $a = 2;
    $b = 5;

    echo $a + $b;
    echo "<br>";

    echo $a - $b;
    echo "<br>";

    echo $a * $b;
    echo "<br>";

    echo $a / $b;
    echo "<br>";

    echo $a % $b;
    echo "<br>";

    echo $a ** $b;
    echo "<br>";

    echo $a++;
    echo "<br>";

    echo ++$a;
    echo "<br>";

    echo $a--;
    echo "<br>";

    echo $a;
    echo "<br>";
?>

