<form action="">
    <input type="email" name="" id="">
    <button type="submit">Gönder</button>
</form>