<?php

    // for, while

    $i = 1;
    $toplam = 0;

    while($i <= 100) {
        $toplam += $i;
        $i += 1;
    }

    echo $toplam;



?>