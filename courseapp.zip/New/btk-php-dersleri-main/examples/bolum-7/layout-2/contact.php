<?php
    $title = "İletişim";
    $content = "views/_contact.php";
    $menu = "views/_menu.php";

    include "layout.php";

?>