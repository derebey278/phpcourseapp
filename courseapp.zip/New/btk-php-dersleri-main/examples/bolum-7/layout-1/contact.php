<?php $title="iletişim"?>
<?php include 'partials/_header.php' ?>

<main>
    <h1>iletişim</h1>
    
    <form action="">
        <input type="text" name="" id="">
        <input type="text" name="" id="">
        <button type="submit">Gönder</button>
    </form>
</main>

<?php include 'partials/_footer.php' ?>