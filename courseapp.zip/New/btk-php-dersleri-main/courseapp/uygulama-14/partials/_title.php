<h1 class="mb-3"><?php echo title; ?></h1>
<p class="lead">
    <?php echo count($kategoriler) ?> kategoride <?php echo count($kurslar) ?> kurs listelenmiştir
</p>