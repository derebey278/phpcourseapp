<?php
function getUsers($username)
{
  include "ayar.php";
  $query = "SELECT * FROM users WHERE username='$username'";
  $sonuc = mysqli_query($baglanti, $query);
  return $sonuc;
}
function getMail($email)
{
  include "ayar.php";
  $query = "SELECT * FROM users WHERE email='$email'";
  $sonuc = mysqli_query($baglanti, $query);
  return $sonuc;
}
function createUsers($username, $email, $password)
{
  include "ayar.php";

  $query = "INSERT INTO users(username, email, password) VALUES (?, ?, ?)";
  $stmt = mysqli_prepare($baglanti, $query);

  mysqli_stmt_bind_param($stmt, "sss", $username, $email, $password);
  if (mysqli_stmt_execute($stmt)) {
    header("Location: login.php");
  }

  return $islem; // return true if successful, false otherwise
}

function getCategories()
{
  include "ayar.php";

  $query = "SELECT * from `category`";
  $sonuc = mysqli_query($baglanti, $query);
  mysqli_close($baglanti);
  return $sonuc;
}

function getCoursesByFilters($categoryId, $keyword, $page)
{
  include "ayar.php";

  $pageCount = 2;
  $offset = ($page - 1) * $pageCount;
  $query = "";
  if (!empty($categoryId)) {
    $query = "from courses_category kc INNER JOIN courses k on kc.courses_id=k.id WHERE kc.category_id=$categoryId and courses_aprov=1";
  } else {
    $query = "from courses WHERE courses_aprov=1";
  }

  if (!empty($keyword)) {
    $query .= " and courses_name LIKE '%$keyword%' or courses_surname LIKE '%$keyword%'";
  }

  $total_sql = "SELECT COUNT(*) " . $query;
  $count_data = mysqli_query($baglanti, $total_sql);
  $count = mysqli_fetch_array($count_data)[0];
  $total_pages = ceil($count / $pageCount);

  $sql = "SELECT * " . $query . " LIMIT $offset, $pageCount";
  $sonuc = mysqli_query($baglanti, $sql);
  mysqli_close($baglanti);
  return [
    "total_pages" => $total_pages,
    "data" => $sonuc,
  ];
}

function getCourses(bool $anasayfa, bool $onay)
{
  include "ayar.php";

  $query = "SELECT * from courses ";

  if ($anasayfa) {
    $query .= "WHERE courses_home=1";
  }

  if ($onay) {
    if (str_contains($query, "WHERE")) {
      $query .= " and courses_aprov=1";
    } else {
      $query .= " WHERE courses_aprov=1";
    }
  }

  $sonuc = mysqli_query($baglanti, $query);
  mysqli_close($baglanti);
  return $sonuc;
}

function getCoursesByKeyword($q)
{
  include "ayar.php";

  $query = "SELECT * from courses WHERE courses_name LIKE '%$q%' or courses_surname LIKE '%$q%'";
  $sonuc = mysqli_query($baglanti, $query);
  mysqli_close($baglanti);
  return $sonuc;
}

function getCategoriesByCourseId(int $courseId)
{
  include "ayar.php";
  $query = "SELECT * FROM `courses_category` kc inner join category c on kc.category_id = c.id WHERE kc.courses_id=$courseId";
  $sonuc = mysqli_query($baglanti, $query);
  mysqli_close($baglanti);
  return $sonuc;
}

function getCategoryById(int $id)
{
  include "ayar.php";

  $query = "SELECT * from category WHERE id=$id";
  $sonuc = mysqli_query($baglanti, $query);
  mysqli_close($baglanti);
  return $sonuc;
}

function getCourseById(int $id)
{
  include "ayar.php";

  $query = "SELECT * from courses WHERE id=$id";
  $sonuc = mysqli_query($baglanti, $query);
  mysqli_close($baglanti);
  return $sonuc;
}

function getCoursesByCategoryId(int $id)
{
  include "ayar.php";

  $query = "SELECT * from courses_category kc INNER JOIN courses k on kc.courses_id=k.id WHERE kc.category_id=$id";
  $sonuc = mysqli_query($baglanti, $query);
  mysqli_close($baglanti);
  return $sonuc;
}

function editCategory(int $id, string $category)
{
  include "ayar.php";

  $query = "UPDATE category SET category_name='$category' WHERE id=$id";
  $sonuc = mysqli_query($baglanti, $query);
  mysqli_close($baglanti);
  return $sonuc;
}

function editCourse(
  int $id,
  string $baslik,
  string $altBaslik,
  string $aciklama,
  string $resim,
  int $onay,
  int $anasayfa
) {
  include "ayar.php";

  $query = "UPDATE courses SET courses_name='$baslik', courses_surname='$altBaslik',courses_desc='$aciklama',courses_img='$resim',courses_aprov=$onay,courses_home=$anasayfa WHERE id=$id";
  $sonuc = mysqli_query($baglanti, $query);
  mysqli_close($baglanti);
  return $sonuc;
}

function clearCourseCategories(int $id)
{
  include "ayar.php";

  $query = "DELETE FROM courses_category WHERE courses_id=$id";
  $sonuc = mysqli_query($baglanti, $query);
  mysqli_close($baglanti);
  return $sonuc;
}

function addCourseCategories(int $id, array $categories)
{
  include "ayar.php";

  $query = "";

  foreach ($categories as $catid) {
    $query .= "INSERT INTO courses_category(courses_id,category_id) VALUES($id,$catid);";
  }

  $sonuc = mysqli_multi_query($baglanti, $query);
  mysqli_close($baglanti);
  return $sonuc;
}

function deleteCategory(int $id)
{
  include "ayar.php";

  $query = "DELETE FROM category WHERE id=$id";
  $sonuc = mysqli_query($baglanti, $query);
  mysqli_close($baglanti);
  return $sonuc;
}

function deleteCourse(int $id)
{
  include "ayar.php";

  $query = "DELETE FROM courses WHERE id=$id";
  $sonuc = mysqli_query($baglanti, $query);
  mysqli_close($baglanti);
  return $sonuc;
}

function createCategory(string $kategori)
{
  include "ayar.php";

  $query = "INSERT INTO category(category_name) VALUES (?)";
  $stmt = mysqli_prepare($baglanti, $query);

  mysqli_stmt_bind_param($stmt, "s", $kategori);
  mysqli_stmt_execute($stmt);
  mysqli_stmt_close($stmt);

  return $stmt;
}

function createCourse(
  string $baslik,
  string $altBaslik,
  string $aciklama,
  string $resim,
  int $yorumSayisi = 0,
  int $begeniSayisi = 0,
  int $onay = 0
) {
  include "ayar.php";

  $query =
    "INSERT INTO courses(courses_name,courses_surname,courses_desc,courses_img,courses_comment,courses_like,courses_aprov) VALUES (?,?,?,?,?,?,?)";
  $stmt = mysqli_prepare($baglanti, $query);

  mysqli_stmt_bind_param(
    $stmt,
    "ssssiii",
    $baslik,
    $altBaslik,
    $aciklama,
    $resim,
    $yorumSayisi,
    $begeniSayisi,
    $onay
  );
  mysqli_stmt_execute($stmt);
  mysqli_stmt_close($stmt);

  return $stmt;
}

function uploadImage(array $file)
{
  if (isset($file)) {
    $dest_path = "./img/";
    $filename = $file["name"];
    $fileSourcePath = $file["tmp_name"];
    $fileDestPath = $dest_path . $filename;

    move_uploaded_file($fileSourcePath, $fileDestPath);
  }
}

function getDb()
{
  $myfile = fopen("db.json", "r");
  $size = filesize("db.json");
  $data = json_decode(fread($myfile, $size), true);
  fclose($myfile);
  return $data;
}

function kursEkle(
  string $baslik,
  string $altBaslik,
  string $resim,
  string $yayinTarihi,
  int $yorumSayisi = 0,
  int $begeniSayisi = 0,
  bool $onay = true
) {
  $db = getDb();

  array_push($db["courses"], [
    "baslik" => $baslik,
    "altBaslik" => $altBaslik,
    "resim" => $resim,
    "yayinTarihi" => $yayinTarihi,
    "yorumSayisi" => $yorumSayisi,
    "begeniSayisi" => $begeniSayisi,
    "onay" => $onay,
  ]);

  $myfile = fopen("db.json", "w");
  fwrite($myfile, json_encode($db, JSON_PRETTY_PRINT));
  fclose($myfile);
}

function urlDuzenle($baslik)
{
  return str_replace(
    [" ", "ç", "@", "."],
    ["-", "c", "", "-"],
    strtolower($baslik)
  );
}

function kisaAciklama($altBaslik)
{
  if (strlen($altBaslik) > 50) {
    return substr($altBaslik, 0, 50) . "...";
  } else {
    return $altBaslik;
  }
}

function safe_html($data)
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
