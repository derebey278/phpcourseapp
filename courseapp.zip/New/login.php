<?php
require "libs/variables.php";
require "libs/functions.php";
$usernameErr = $passwordErr = "";
$username = $password = "";
session_start();
if (isset($_SESSION["loginin"]) && $_SESSION["loginin"] == true) {
    header("Location: index.php");
  }

if (isset($_POST["login"])) {
  $username = $_POST["username"];
  $password = $_POST["password"];

  
  $data = getUsers($_POST["username"]);
  $veri = mysqli_fetch_assoc($data);
  if (mysqli_num_rows($data) == 1) {
    if ($veri["username"] == $username && $veri["password"] == $password) {
      $_SESSION["username"] = $username;
      $_SESSION["password"] = $password;
      $_SESSION["user_type"] = $veri['user_type'];

      $_SESSION["loginin"] = true;
      header("Location: index.php");
    } else {
      $passwordErr = "Girilen Sifre Dogru degil";
    }
  } else {
    $usernameErr = "Kullanici Adi Hatalidir";
  }
}
?>

<?php include "partials/_header.php"; ?>
<?php include "partials/_navbar.php"; ?>

<div class="container my-3">

<div class="row">
    <div class="col-12">
        <form action="login.php" method="post">
        <div class="mb-3">
            <label for="username">Kullanıcı Adı</label>
            <input type="text" name="username" class="form-control" value="<?= $username ?>">
              <div class="text-danger"><?php echo $usernameErr; ?></div>
        </div>
        <div class="mb-3">
            <label for="password">Parola</label>
            <input type="password" name="password" class="form-control">
              <div class="text-danger"><?php echo $passwordErr; ?></div>
        </div>
        <button type="submit" class="btn btn-primary" name="login">Login</button>
        </form>
    </div>
    </div>

</div>
<?php include "partials/_footer.php"; ?>
