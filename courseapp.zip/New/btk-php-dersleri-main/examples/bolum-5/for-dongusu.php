<?php

    // for, while

    for($i = 20; $i <= 100; $i += 1) {
        if ($i % 2 == 0) {
            echo $i."<br>";
        }
    }

    echo "bitti";


?>