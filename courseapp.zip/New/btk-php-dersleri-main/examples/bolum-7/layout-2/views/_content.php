<ul>
    <li>Samsung S23</li>
    <li>Samsung S24</li>
</ul>