<?php
    $title = "Anasayfa";
    $content = "views/_content.php";
    $menu = "views/_menu.php";

    include "layout.php";

?>