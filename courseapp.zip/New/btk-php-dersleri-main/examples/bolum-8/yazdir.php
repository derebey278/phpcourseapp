<?php

    $query = $_GET['q'];
    $category = $_GET['category'];

    echo $query;
    echo "<br>";
    echo $category;


?>