<footer>
        <p>Tüm hakları saklıdır.</p>
    </footer>


</body>
</html>