<?php include 'partials/_variables.php'?>
<?php include 'partials/_header.php' ?>

<main>
    <h1>Ürün listesi</h1>
    <?php include 'partials/_urunler.php' ?>
    <nav>
        <a href="">1</a>
        <a href="">2</a>
        <a href="">3</a>
    </nav>
</main>

<?php include 'partials/_footer.php' ?>