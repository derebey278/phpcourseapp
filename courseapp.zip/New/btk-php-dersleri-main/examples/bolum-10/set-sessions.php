<?php


    session_start();

    $_SESSION["username"] = "sadikturan";
    $_SESSION["password"] = "12345";
?>