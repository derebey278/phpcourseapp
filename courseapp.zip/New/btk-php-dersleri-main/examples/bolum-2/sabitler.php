<?php
    // PHP Sabitler: 
    // Sabitler veri saklamak için kullanılır ancak tanımlanan değer değiştirilemez.

    // define("baglanti", "mysql bağlantı cümlesi");
    const baglanti = "mysql bağlantı cümlesi";
    const username = "sadikturan";
    const password = "1234";

    echo baglanti;

?>